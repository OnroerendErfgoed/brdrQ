<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AutocorrectBordersProcessingAlgorithm</name>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="189"/>
        <source>brdrQ - AutoCorrectBorders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="196"/>
        <source>brdrQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="214"/>
        <source>This script searches for overlap relevance between thematic borders and reference borders, and creates a resulting border based on the overlapping areas that are relevant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="226"/>
        <source>https://github.com/OnroerendErfgoed/brdrQ/blob/development/docs/autocorrectborders.md</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="238"/>
        <source>THEMATIC LAYER</source>
        <translation type="unfinished">Thematische laag</translation>
    </message>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="264"/>
        <source>REFERENCE LAYER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_algorithm_autocorrectborders.py" line="344"/>
        <source>Working folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrdrQPlugin</name>
    <message>
        <location filename="../brdrq_plugin.py" line="174"/>
        <source>brdrQ - version</source>
        <translation>brdrQ - versie</translation>
    </message>
</context>
<context>
    <name>brdrQDockWidgetBase</name>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="17"/>
        <source>brdrQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="128"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:7.8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;                                &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;                                 &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;                                 &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;LOG                             &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="49"/>
        <source>GRAFIEK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="56"/>
        <source>VISUALISEER predictions</source>
        <translation>visualiseer voorspellingen</translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="112"/>
        <source>SETTINGS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="119"/>
        <source>HELP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="86"/>
        <source>alleen geselecteerde features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="24"/>
        <source> RESET GEOM - (!)enkel binnen sessie (!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="71"/>
        <source>Feature-selectie-opties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="99"/>
        <source>Selecteer feature(s) op kaart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="142"/>
        <source>Lijst van (alle, geselecteerde of aangeklikte) features:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../brdrq_dockwidget_featurealigner.ui" line="158"/>
        <source> SAVE GEOM - (!) Wijzigt uw dataset(!)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
